function addRow(name, email, phone){
    var table = document.getElementById("myTable").getElementsByTagName('tbody')[0];
    newRow = table.insertRow();

    var cell1 = newRow.insertCell(0);
    var cell2 = newRow.insertCell(1);
    var cell3 = newRow.insertCell(2);
    var cell4 = newRow.insertCell(3);

    cell1.innerHTML = table.rows.length;
    cell2.innerHTML = name;
    cell3.innerHTML = email;
    cell4.innerHTML = phone;

}

    addRow("Mukhriz Jamil Asoka", "mukriz@corp.jp", "651181187223");

    var table = document.getElementById("myTable");
    var header = table.createTHead();
    var row = header.insertRow(0);
    var headers = ["#", "Name", "Email", "Phone"];
    for (var i = 0; i < headers.length; i++){
        var cell = row.insertCell(i);
        cell.innerHTML = headers[i];
}

    var rows = document.querySelectorAll("#myTable tbody tr");
    rows.forEach(function(row){
        row.addEventListener("click", function(){
            this.remove();
        });
});