function Book(bookName, authorName){
    this.bookName = bookName;
    this.authorName = authorName;
    }

Book.prototype.price = 0;

function createBook(){
    const bookName = document.getElementById('bookName').value;
    const authorName = document.getElementById('authorName').value;

    const book = new Book(bookName, authorName);
    document.getElementById('bookInfo').innerText = `Book Name: ${book.bookName}\nAuthor Name: ${book.authorName}`;
}
