function createProduct(){
    const productName = document.getElementById('productName').value;
    const quantity = parseInt(document.getElementById('quantity').value);
    const price = parseFloat(document.getElementById('price').value);

    const product = {
        productName: productName,
        quantity: quantity,
        price: price
    };

    document.getElementById('productInfo').innerText = `Product Name: ${product.productName}\nQuantity: ${product.quantity}\nPrice: $${product.price}`;
}