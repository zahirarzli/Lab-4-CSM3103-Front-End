function Employee(employeeName, employeeId, salary){
    this.employeeName = employeeName;
    this.employeeId = employeeId;
    this.salary = salary;
}

function Manager(managerName, branch){
    this.managerName = managerName;
    this.branch = branch;
}

Manager.prototype = new Employee();

function createManager(){
    const employeeName = document.getElementById('employeeName').value;
    const employeeId = document.getElementById('employeeId').value; 
    const salary = parseFloat(document.getElementById('salary').value);
    const managerName = document.getElementById('managerName').value;
    const branch = document.getElementById('branch').value;

    const manager = new Manager(employeeName, employeeId, salary, managerName, branch);
    document.getElementById('managerInfo').innerText = `Employee Name: 
    ${manager.employeeName}\nEmployee ID: 
    ${manager.employeeId}\nSalary: $${manager.salary}\nManager Name: 
    ${manager.managerName}\nBranch: ${manager.branch}`;
}