function sumOfDigits(number){
    if(number < 10){
        return number;
    } else{
        return (number % 10) + sumOfDigits(Math.floor(number / 10));
    }
}

function power(x, y){
    if(y === 0){
        return 1;
    } else{
        return x * power(x, y-1);
    }
}

function sumDigits(){
    const number = parseInt(document.getElementById('number').value);
    const result = sumOfDigits(number);
    document.getElementById('sumResult').innerText = `Sum of digits: ${result}`;
}

function computePower(){
    const base = parseInt(document.getElementById('base').value);
    const exponent = parseInt(document.getElementById('exponent').value);
    const result = power(base, exponent);
    document.getElementById('powerResult').innerText = `${base} raised to the power ${exponent}: ${result}`;
}