var smallSquare1 = document.getElementById("smallSquare1");
var smallSquare2 = document.getElementById("smallSquare2");
var startBtn = document.getElementById("startBtn");
var stopBtn = document.getElementById("stopBtn");
var animationInterval;

function moveSquares() {
    animationInterval = setInterval(function() {
        moveSquare(smallSquare1);
        moveSquare(smallSquare2);
    }, 1000);
}

function moveSquare(square) {
    var maxX = 280;
    var maxY = 280;

    var newX = Math.floor(Math.random() * Math.floor(maxX));
    var newY = Math.floor(Math.random() * Math.floor(maxY));

    square.style.left = newX + "px";
    square.style.top = newY + "px";
}

function stopAnimation() {
    clearInterval(animationInterval);
}

startBtn.addEventListener("click", moveSquares);
stopBtn.addEventListener("click", stopAnimation);
