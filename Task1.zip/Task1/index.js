function square(number){
    return number * number;
}

function sumOfCubes(num1, num2){
    return Math.pow(num1, 3) + Math.pow(num2, 3);
}

function reverseNumber(number){
    let reversedNumber = 0;
    while (number > 0){
        reversedNumber = reversedNumber * 10 + (number % 10);
        number = Math.floor(number / 10);
    }
    return reversedNumber;
}

function printDivisibleNumbers(z){
    let output = "";
    for(let i = 1; i <= 100; i++){
        if(i % z === 0){
            output += i + ", ";
        }
    }
    return output.slice(0, -2); 
}

function displayResults(){
    const number = parseInt(document.getElementById("inputNumber").value);
    const outputSquare = square(number);
    const num1 = parseInt(document.getElementById("inputNum1").value);
    const num2 = parseInt(document.getElementById("inputNum2").value);
    const outputSumOfCubes = sumOfCubes(num1, num2);
    const numberToReverse = parseInt(document.getElementById("inputReverse").value);
    const outputReverse = reverseNumber(numberToReverse);
    const z = parseInt(document.getElementById("inputDivisible").value);
    const outputDivisible = printDivisibleNumbers(z);

    document.getElementById("resultSquare").innerText = "Square: " + outputSquare;
    document.getElementById("resultSumOfCubes").innerText = "Sum of Cubes: " + outputSumOfCubes;
    document.getElementById("resultReverse").innerText = "Reversed Number: " + outputReverse;
    document.getElementById("resultDivisible").innerText = "Numbers Divisible by " + z + ":" + outputDivisible;
}